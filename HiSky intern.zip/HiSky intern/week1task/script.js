
document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");
    const fields = document.querySelectorAll(".field .item");
    const errorTexts = document.querySelectorAll(".error-txt");

    form.addEventListener("submit", (e) => {
        let isValid = true;
        
        fields.forEach((field, index) => {
            if (field.value.trim() === "") {
                errorTexts[index].style.display = "block";
                isValid = false;
            } else {
                errorTexts[index].style.display = "none";
            }
        });

        if (!isValid) {
            e.preventDefault();
        }
    });
});
